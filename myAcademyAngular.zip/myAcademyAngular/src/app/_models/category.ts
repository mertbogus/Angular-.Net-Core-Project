export class Category{
  id;
  categoryName;
}
